const zmien = function() {

    var d_input_w = document.getElementById("d_input_w").value;
    var d_output_w = document.getElementById("d_output_w");
    if( d_input_w != "" )d_output_w.innerHTML =   d_input_w[8]+d_input_w[9]+"."+d_input_w[5]+d_input_w[6]+"."+d_input_w[0]+d_input_w[1]+d_input_w[2]+d_input_w[3];

    var nr_w = document.getElementById("nr_w").value;
    var nr_w_o = document.getElementById("nr_w_o");
    w = ""
    if(nr_w>999 || nr_w<10000) w = nr_w;
    if( nr_w != "" )nr_w_o.innerHTML = w;

    var seria = document.getElementById("seria").value;
    var nr_dowodu = document.getElementById("nr_dowodu").value;
    var SiNR_d_o = document.getElementById("SiNR_d_o");
    if( _ != "" )SiNR_d_o.innerHTML = seria + "  " + nr_dowodu;

    var nr_P_in = document.getElementById("nr_P_in").value;
    var nr_P_o = document.getElementById("nr_P_o");
    w=""
    if(nr_P_in>9999999 || nr_w<100000000) w = nr_P_in;
    if( nr_P_in != "" )nr_P_o.innerHTML = w;
    
    var naz_in = document.getElementById("naz_in").value;
    var naz_o = document.getElementById("naz_o");
    if( naz_in != "" )naz_o.innerHTML = naz_in;

    var imie_in = document.getElementById("imie_in").value;
    var imie_o = document.getElementById("imie_o");
    if( imie_in != "" )imie_o.innerHTML = imie_in;

    var ul_in = document.getElementById("ul_in").value;
    var ul_o = document.getElementById("ul_o");
    if( ul_in != "" )ul_o.innerHTML = ul_in;

    var nr_dIm_in = document.getElementById("nr_dIm_in").value;
    var nr_dIm_o = document.getElementById("nr_dIm_o");
    if( nr_dIm_in != "" )nr_dIm_o.innerHTML = nr_dIm_in;

    var k_d_in = document.getElementById("k_d_in").value;
    var k_d_o = document.getElementById("k_d_o");
    if( k_d_in != "" )k_d_o.innerHTML = k_d_in;

    var mias_in = document.getElementById("mias_in").value;
    var mias_o = document.getElementById("mias_o");
    if( mias_in != "" )mias_o.innerHTML = mias_in;

    var e_m_in = document.getElementById("e_m_in").value;
    var e_m_o = document.getElementById("e_m_o");
    if( e_m_in != "" ) e_m_o.innerHTML = e_m_in;
}